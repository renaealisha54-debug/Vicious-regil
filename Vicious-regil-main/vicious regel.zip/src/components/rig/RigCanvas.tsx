
"use client";

import React, { useRef, useEffect, useCallback } from 'react';
import { 
  GRID_SIZE, 
  POINT_RADIUS, 
  POINT_META, 
  BONES, 
  Keyframe, 
  PointName,
  CanvasDimensions,
  ViewType,
  PosePoint
} from '@/lib/rig-constants';

interface RigCanvasProps {
  points: Keyframe;
  onPointsChange: (points: Keyframe) => void;
  snapMode: boolean;
  activePoint: PointName | null;
  setActivePoint: (point: PointName | null) => void;
  dimensions: CanvasDimensions;
  isReacting?: boolean;
  referenceImage?: string | null;
  viewType: ViewType;
  isGlideMode?: boolean;
  detailLevel: 'simple' | 'full';
}

export const RigCanvas: React.FC<RigCanvasProps> = ({ 
  points, 
  onPointsChange, 
  snapMode, 
  activePoint, 
  setActivePoint,
  dimensions,
  isReacting,
  referenceImage,
  viewType,
  isGlideMode,
  detailLevel
}) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const draggingRef = useRef<PointName | null>(null);
  const startDragPos = useRef<{x: number, y: number} | null>(null);
  const startPoints = useRef<Keyframe | null>(null);
  const imageRef = useRef<HTMLImageElement | null>(null);

  useEffect(() => {
    if (referenceImage) {
      const img = new Image();
      img.src = referenceImage;
      img.onload = () => {
        imageRef.current = img;
        draw(points);
      };
    } else {
      imageRef.current = null;
      draw(points);
    }
  }, [referenceImage]);

  const draw = useCallback((pts: Keyframe) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, dimensions.width, dimensions.height);

    if (imageRef.current) {
      ctx.globalAlpha = 0.3;
      ctx.drawImage(imageRef.current, 0, 0, dimensions.width, dimensions.height);
      ctx.globalAlpha = 1.0;
    }

    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    for (let x = 0; x <= dimensions.width; x += GRID_SIZE) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, dimensions.height); ctx.stroke();
    }
    for (let y = 0; y <= dimensions.height; y += GRID_SIZE) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(dimensions.width, y); ctx.stroke();
    }

    // Reaction Glow
    if (isReacting) {
       ctx.beginPath();
       ctx.arc(pts.head.x, pts.head.y, 70, 0, Math.PI * 2);
       const grad = ctx.createRadialGradient(pts.head.x, pts.head.y, 20, pts.head.x, pts.head.y, 70);
       grad.addColorStop(0, "rgba(94, 129, 243, 0.3)");
       grad.addColorStop(1, "rgba(94, 129, 243, 0)");
       ctx.fillStyle = grad;
       ctx.fill();
    }

    // ADAPT MODE: Real Character Rendering
    if (detailLevel === 'full') {
      ctx.lineCap = "round";
      ctx.lineJoin = "round";

      // Render Skin/Body
      const drawLimb = (p1: PosePoint, p2: PosePoint, width: number, color: string = "#FDE68A") => {
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.strokeStyle = color;
        ctx.lineWidth = width;
        ctx.stroke();
      };

      // Torso
      ctx.beginPath();
      ctx.moveTo(pts.torsoTop.x - 20, pts.torsoTop.y);
      ctx.lineTo(pts.torsoTop.x + 20, pts.torsoTop.y);
      ctx.lineTo(pts.torsoBottom.x + 25, pts.torsoBottom.y);
      ctx.lineTo(pts.torsoBottom.x - 25, pts.torsoBottom.y);
      ctx.closePath();
      ctx.fillStyle = "#3B82F6"; // Shirt
      ctx.fill();

      // Arms
      drawLimb(pts.shoulderL, pts.elbowL, 14);
      drawLimb(pts.elbowL, pts.handL, 12);
      drawLimb(pts.shoulderR, pts.elbowR, 14);
      drawLimb(pts.elbowR, pts.handR, 12);

      // Legs
      drawLimb(pts.hipL, pts.kneeL, 18, "#1F2937"); // Pants
      drawLimb(pts.kneeL, pts.footL, 16, "#1F2937");
      drawLimb(pts.hipR, pts.kneeR, 18, "#1F2937");
      drawLimb(pts.kneeR, pts.footR, 16, "#1F2937");

      // Head
      ctx.beginPath();
      ctx.arc(pts.head.x, pts.head.y, 28, 0, Math.PI * 2);
      ctx.fillStyle = "#FDE68A";
      ctx.fill();
      
      // Hair (Visual only)
      ctx.beginPath();
      ctx.arc(pts.head.x, pts.head.y - 5, 29, Math.PI, 0);
      ctx.fillStyle = "#4B2C20";
      ctx.fill();

      // Expressions (Visual only)
      const exp = pts.expression || 'neutral';
      ctx.lineWidth = 2;
      ctx.strokeStyle = "#1F2937";
      ctx.fillStyle = "#1F2937";

      // Eyes
      if (exp === 'closed') {
        ctx.beginPath(); ctx.moveTo(pts.head.x - 12, pts.head.y - 5); ctx.lineTo(pts.head.x - 4, pts.head.y - 5); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(pts.head.x + 4, pts.head.y - 5); ctx.lineTo(pts.head.x + 12, pts.head.y - 5); ctx.stroke();
      } else {
        ctx.beginPath(); ctx.arc(pts.head.x - 8, pts.head.y - 5, 3, 0, Math.PI * 2); ctx.fill();
        ctx.beginPath(); ctx.arc(pts.head.x + 8, pts.head.y - 5, 3, 0, Math.PI * 2); ctx.fill();
      }

      // Mouth
      if (exp === 'smile') {
        ctx.beginPath(); ctx.arc(pts.head.x, pts.head.y + 8, 8, 0.1 * Math.PI, 0.9 * Math.PI); ctx.stroke();
      } else if (exp === 'yell') {
        ctx.beginPath(); ctx.ellipse(pts.head.x, pts.head.y + 12, 6, 8, 0, 0, Math.PI * 2); ctx.stroke();
      } else if (exp === 'cry') {
        ctx.beginPath(); ctx.arc(pts.head.x, pts.head.y + 12, 6, 1.1 * Math.PI, 1.9 * Math.PI); ctx.stroke();
      } else {
        ctx.beginPath(); ctx.moveTo(pts.head.x - 5, pts.head.y + 10); ctx.lineTo(pts.head.x + 5, pts.head.y + 10); ctx.stroke();
      }

    } else {
      // SIMPLE RIG DRAWING
      BONES.forEach(([a, b]) => {
        const p1 = pts[a], p2 = pts[b];
        if (!p1 || !p2) return;
        ctx.beginPath();
        ctx.moveTo(p1.x, p1.y);
        ctx.lineTo(p2.x, p2.y);
        ctx.strokeStyle = POINT_META[a].color;
        ctx.lineWidth = 4;
        ctx.lineCap = "round";
        ctx.stroke();
      });
    }

    // Draw Interactive Handles
    (Object.entries(pts) as [PointName, PosePoint][]).forEach(([key, pt]) => {
      if (key === 'expression') return;
      const meta = POINT_META[key];
      const isActive = activePoint === key;

      ctx.beginPath();
      ctx.arc(pt.x, pt.y, POINT_RADIUS + (isActive ? 4 : 0), 0, Math.PI * 2);
      ctx.fillStyle = isActive ? "#FFF" : meta.color;
      ctx.globalAlpha = isActive ? 1.0 : 0.6;
      ctx.fill();
      ctx.globalAlpha = 1.0;

      if (isActive) {
        ctx.shadowBlur = 10;
        ctx.shadowColor = meta.color;
        ctx.stroke();
        ctx.shadowBlur = 0;
      }
    });

  }, [activePoint, snapMode, dimensions, isReacting, viewType, detailLevel]);

  useEffect(() => {
    draw(points);
  }, [points, draw]);

  const getCanvasCoords = (e: React.MouseEvent | React.TouchEvent) => {
    const canvas = canvasRef.current;
    if (!canvas) return { x: 0, y: 0 };
    const rect = canvas.getBoundingClientRect();
    const clientX = 'touches' in e ? (e as React.TouchEvent).touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? (e as React.TouchEvent).touches[0].clientY : (e as React.MouseEvent).clientY;
    
    const scaleX = dimensions.width / rect.width;
    const scaleY = dimensions.height / rect.height;
    
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY
    };
  };

  const handleDown = (e: React.MouseEvent | React.TouchEvent) => {
    const { x, y } = getCanvasCoords(e);
    let hit: PointName | null = null;
    
    (Object.entries(points) as [PointName, PosePoint][]).forEach(([key, pt]) => {
      if (key === 'expression') return;
      if (Math.hypot(x - pt.x, y - pt.y) <= POINT_RADIUS + 15) {
        hit = key;
      }
    });

    if (hit) {
      draggingRef.current = hit;
      setActivePoint(hit);
      startDragPos.current = { x, y };
      startPoints.current = JSON.parse(JSON.stringify(points));
    } else {
      setActivePoint(null);
    }
  };

  const handleMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!draggingRef.current || !startDragPos.current || !startPoints.current) return;
    
    const { x, y } = getCanvasCoords(e);
    const dx = x - startDragPos.current.x;
    const dy = y - startDragPos.current.y;

    if (isGlideMode) {
      const nextPoints = JSON.parse(JSON.stringify(startPoints.current));
      Object.keys(nextPoints).forEach((key) => {
        if (key === 'expression') return;
        const k = key as PointName;
        nextPoints[k] = { 
          x: startPoints.current![k].x + dx, 
          y: startPoints.current![k].y + dy 
        };
      });
      onPointsChange(nextPoints);
    } else {
      let nx = snapMode ? Math.round(x / GRID_SIZE) * GRID_SIZE : x;
      let ny = snapMode ? Math.round(y / GRID_SIZE) * GRID_SIZE : y;
      
      onPointsChange({
        ...points,
        [draggingRef.current]: { x: nx, y: ny }
      });
    }
  };

  const handleUp = () => {
    draggingRef.current = null;
    startDragPos.current = null;
    startPoints.current = null;
  };

  return (
    <div className="relative group p-1 bg-muted/20 border border-white/5 rounded-2xl overflow-hidden shadow-3xl">
      <canvas
        ref={canvasRef}
        width={dimensions.width}
        height={dimensions.height}
        onMouseDown={handleDown}
        onMouseMove={handleMove}
        onMouseUp={handleUp}
        onMouseLeave={handleUp}
        onTouchStart={handleDown}
        onTouchMove={handleMove}
        onTouchEnd={handleUp}
        className="block bg-background cursor-crosshair touch-none"
        style={{
          width: '100%',
          maxWidth: dimensions.width,
          height: 'auto',
          aspectRatio: `${dimensions.width}/${dimensions.height}`
        }}
      />
    </div>
  );
};
