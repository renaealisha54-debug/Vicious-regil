
"use client";

import React, { useRef } from 'react';
import { Keyframe, PointName, TEMPLATES, CanvasDimensions, ViewType, Expression } from '@/lib/rig-constants';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { 
  Plus, Play, Pause, Download, Trash2, Maximize2, Minimize2, 
  Move, Zap, Smile, Frown, Megaphone, EyeOff, X, 
  UserRound, Layers, Activity, History, Video, Loader2
} from 'lucide-react';
import { cn } from '@/lib/utils';

interface ControlsProps {
  points: Keyframe;
  onPointsChange: (points: Keyframe) => void;
  snapMode: boolean;
  onSnapToggle: () => void;
  onCapture: () => void;
  isPlaying: boolean;
  onPlayToggle: () => void;
  onClearTimeline: () => void;
  fps: number;
  onFpsChange: (val: number) => void;
  onExport: () => void;
  dimensions: CanvasDimensions;
  onDimensionsChange: (dims: CanvasDimensions) => void;
  playbackMode: 'loop' | 'once' | 'ping-pong';
  onPlaybackModeChange: (mode: 'loop' | 'once' | 'ping-pong') => void;
  isFloating: boolean;
  onFloatingToggle: () => void;
  referenceImage: string | null;
  onReferenceImageChange: (img: string | null) => void;
  isAvatarVisible: boolean;
  onAvatarVisibilityToggle: () => void;
  viewType: ViewType;
  onViewTypeChange: (view: ViewType) => void;
  isGlideMode: boolean;
  onGlideModeToggle: () => void;
  detailLevel: 'simple' | 'full';
  onDetailLevelToggle: () => void;
}

export const Controls: React.FC<ControlsProps> = ({
  points,
  onPointsChange,
  snapMode,
  onSnapToggle,
  onCapture,
  isPlaying,
  onPlayToggle,
  onClearTimeline,
  dimensions,
  onDimensionsChange,
  playbackMode,
  onPlaybackModeChange,
  isFloating,
  onFloatingToggle,
  viewType,
  onViewTypeChange,
  isGlideMode,
  onGlideModeToggle,
  detailLevel,
  onDetailLevelToggle,
  onExport
}) => {
  const setExpression = (exp: Expression) => {
    onPointsChange({ ...points, expression: exp });
  };

  const flipRig = () => {
    const center = dimensions.width / 2;
    const flipped = { ...points };
    Object.keys(flipped).forEach(key => {
      if (key === 'expression') return;
      const k = key as PointName;
      flipped[k].x = center + (center - points[k].x);
    });
    onPointsChange(flipped);
  };

  return (
    <div className="flex flex-col gap-6 p-1 h-full scrollbar-hide">
      {/* ADAPT ENGINE CONFIG */}
      <div className="space-y-3 p-3 bg-primary/5 border border-primary/20 rounded-xl">
        <h4 className="text-[10px] font-black tracking-widest text-primary uppercase flex items-center gap-2">
          <Activity className="w-3 h-3" /> Synthesis Engine
        </h4>
        <div className="flex flex-col gap-2">
          <Button 
            variant={detailLevel === 'full' ? "default" : "outline"} 
            className="w-full gap-2 text-[10px] h-8 font-bold"
            onClick={onDetailLevelToggle}
          >
            <UserRound className="w-3 h-3" />
            {detailLevel === 'full' ? 'ADAPT: REAL CHARACTER' : 'RIG: SKELETON ONLY'}
          </Button>
          <div className="grid grid-cols-2 gap-2">
            <Button variant="outline" className="text-[10px] h-8" onClick={flipRig}>Flip Body</Button>
            <Button variant={isGlideMode ? "default" : "outline"} className="text-[10px] h-8 gap-2" onClick={onGlideModeToggle}>
              <Move className="w-3 h-3" /> Glide
            </Button>
          </div>
        </div>
      </div>

      {/* STUDIO VIEWPORT */}
      <div className="space-y-3">
        <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase px-1">Studio Viewport</h4>
        <div className="grid grid-cols-2 gap-2">
          <div className="space-y-1">
             <Label className="text-[9px] uppercase opacity-50">Width</Label>
             <input 
               type="number" 
               className="w-full bg-muted/20 border border-white/5 rounded px-2 py-1 text-xs" 
               value={dimensions.width} 
               onChange={(e) => onDimensionsChange({...dimensions, width: Number(e.target.value)})}
             />
          </div>
          <div className="space-y-1">
             <Label className="text-[9px] uppercase opacity-50">Height</Label>
             <input 
               type="number" 
               className="w-full bg-muted/20 border border-white/5 rounded px-2 py-1 text-xs" 
               value={dimensions.height} 
               onChange={(e) => onDimensionsChange({...dimensions, height: Number(e.target.value)})}
             />
          </div>
        </div>
      </div>

      {/* FACE EXPRESSIONS */}
      <div className="space-y-3">
        <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase px-1">Facial State</h4>
        <div className="grid grid-cols-5 gap-1">
          <Button variant={points.expression === 'smile' ? "secondary" : "outline"} size="icon" className="h-8 w-8" onClick={() => setExpression('smile')}><Smile className="w-4 h-4" /></Button>
          <Button variant={points.expression === 'cry' ? "secondary" : "outline"} size="icon" className="h-8 w-8" onClick={() => setExpression('cry')}><Frown className="w-4 h-4" /></Button>
          <Button variant={points.expression === 'yell' ? "secondary" : "outline"} size="icon" className="h-8 w-8" onClick={() => setExpression('yell')}><Megaphone className="w-4 h-4" /></Button>
          <Button variant={points.expression === 'closed' ? "secondary" : "outline"} size="icon" className="h-8 w-8" onClick={() => setExpression('closed')}><EyeOff className="w-4 h-4" /></Button>
          <Button variant={!points.expression || points.expression === 'neutral' ? "secondary" : "outline"} size="icon" className="h-8 w-8" onClick={() => setExpression('neutral')}><X className="w-4 h-4" /></Button>
        </div>
      </div>

      {/* POSE TEMPLATES */}
      <div className="space-y-3">
        <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase px-1">Pose Templates</h4>
        <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto pr-1 scrollbar-hide">
          {Object.entries(TEMPLATES).map(([name, data]) => (
            <Button
              key={name}
              variant="outline"
              size="sm"
              className="text-[10px] h-8 justify-start truncate"
              onClick={() => onPointsChange(JSON.parse(JSON.stringify(data)))}
            >
              {name}
            </Button>
          ))}
        </div>
      </div>

      {/* ENGINE PLAYBACK */}
      <div className="space-y-3 mt-auto pt-4 border-t border-white/5">
        <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase px-1">Playback Control</h4>
        <div className="grid grid-cols-2 gap-2">
          <Button variant={isPlaying ? "destructive" : "default"} className="w-full gap-2 h-9" onClick={onPlayToggle}>
            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            {isPlaying ? "Stop" : "Play"}
          </Button>
          <Button variant="secondary" className="w-full gap-2 h-9" onClick={onCapture}>
            <Plus className="w-4 h-4" /> Frame
          </Button>
        </div>
        <div className="flex items-center gap-1 bg-muted/20 p-1 rounded-lg">
           {(['once', 'loop', 'ping-pong'] as const).map((mode) => (
             <Button
                key={mode}
                variant={playbackMode === mode ? "default" : "ghost"}
                size="sm"
                className="flex-1 text-[9px] h-7 uppercase font-bold"
                onClick={() => onPlaybackModeChange(mode)}
             >
                {mode}
             </Button>
           ))}
        </div>
      </div>

      <div className="pt-2 space-y-2">
        <Button variant="outline" className="w-full gap-2 border-primary/20 hover:bg-primary/10 text-primary h-9" onClick={onExport}>
          <Download className="w-4 h-4" /> Compile Sprites
        </Button>
        <Button variant="ghost" className="w-full gap-2 text-muted-foreground hover:text-destructive h-9" onClick={onClearTimeline}>
          <Trash2 className="w-4 h-4" /> Clear Timeline
        </Button>
      </div>
    </div>
  );
};
