
import React from 'react';
import { Keyframe, PointName, POINT_META, BONES, DEFAULT_CANVAS_W, DEFAULT_CANVAS_H } from '@/lib/rig-constants';
import { Button } from '@/components/ui/button';
import { Trash2, Copy, Plus, Zap } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TimelineProps {
  frames: Keyframe[];
  currentIndex: number;
  onSelectFrame: (index: number) => void;
  onDeleteFrame: (index: number) => void;
  onDuplicateFrame: (index: number) => void;
  onInterpolate: (index: number) => void;
  isInterpolating: boolean;
}

const MiniPreview: React.FC<{ pts: Keyframe }> = ({ pts }) => {
  const S = 0.15;
  return (
    <svg width={DEFAULT_CANVAS_W * S} height={DEFAULT_CANVAS_H * S} className="bg-background/40 rounded border border-white/5">
      {BONES.map(([a, b], i) => {
        const p1 = pts[a], p2 = pts[b];
        if (!p1 || !p2) return null;
        return (
          <line
            key={i}
            x1={p1.x * S} y1={p1.y * S}
            x2={p2.x * S} y2={p2.y * S}
            stroke="rgba(255,255,255,0.2)"
            strokeWidth={1}
          />
        );
      })}
      {(Object.entries(pts) as [PointName, {x:number, y:number}][]).map(([k, p]) => {
        if (!p || k === 'expression' as any) return null;
        return (
          <circle key={k} cx={p.x * S} cy={p.y * S} r={1} fill={POINT_META[k]?.color || '#FFF'} />
        );
      })}
    </svg>
  );
};

export const Timeline: React.FC<TimelineProps> = ({ 
  frames, 
  currentIndex, 
  onSelectFrame, 
  onDeleteFrame, 
  onDuplicateFrame,
  onInterpolate,
  isInterpolating
}) => {
  return (
    <div className="flex flex-col gap-3 h-full">
      <div className="flex items-center justify-between px-1">
        <h3 className="text-xs font-bold tracking-widest text-muted-foreground uppercase flex items-center gap-2">
          Animation Stream <span className="text-[10px] px-1.5 py-0.5 bg-primary/20 text-primary rounded">{frames.length}</span>
        </h3>
      </div>
      
      <div className="flex-1 overflow-x-auto overflow-y-hidden flex gap-2 pb-4 timeline-scroll scroll-smooth">
        {frames.length === 0 ? (
          <div className="w-full flex flex-col items-center justify-center border-2 border-dashed border-white/5 rounded-2xl text-muted-foreground p-8">
            <Plus className="w-8 h-8 mb-2 opacity-20" />
            <p className="text-xs">Timeline empty</p>
          </div>
        ) : (
          frames.map((frame, idx) => (
            <div 
              key={idx}
              className={cn(
                "group relative flex-shrink-0 flex flex-col items-center gap-2 p-2 rounded-xl border transition-all duration-300",
                currentIndex === idx 
                  ? "bg-primary/10 border-primary ring-1 ring-primary/30" 
                  : "bg-card border-white/5 hover:border-white/20"
              )}
            >
              <div 
                className="cursor-pointer"
                onClick={() => onSelectFrame(idx)}
              >
                <MiniPreview pts={frame} />
                <div className="absolute top-1 left-1 px-1 rounded bg-background/80 text-[8px] font-bold text-muted-foreground border border-white/5">
                  F{idx + 1}
                </div>
              </div>

              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="w-6 h-6 text-muted-foreground hover:text-foreground"
                  onClick={() => onDuplicateFrame(idx)}
                >
                  <Copy className="w-3 h-3" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="icon" 
                  className="w-6 h-6 text-destructive/70 hover:text-destructive"
                  onClick={() => onDeleteFrame(idx)}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
                {idx < frames.length - 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    className="w-6 h-6 text-accent hover:text-accent-foreground"
                    title="Interpolate"
                    disabled={isInterpolating}
                    onClick={() => onInterpolate(idx)}
                  >
                    <Zap className={cn("w-3 h-3", isInterpolating && "animate-pulse")} />
                  </Button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};
