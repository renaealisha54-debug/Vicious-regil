
"use client";

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { RigCanvas } from '@/components/rig/RigCanvas';
import { Timeline } from '@/components/rig/Timeline';
import { Controls } from '@/components/rig/Controls';
import { 
  Keyframe, 
  TEMPLATES, 
  PointName, 
  CanvasDimensions,
  DEFAULT_CANVAS_W,
  DEFAULT_CANVAS_H,
  ViewType
} from '@/lib/rig-constants';
import { interpolateKeyframes } from '@/ai/flows/interpolate-keyframes-flow';
import { generateVideo } from '@/ai/flows/generate-video-flow';
import { useCollection, useFirestore } from '@/firebase';
import { collection, addDoc, query, orderBy, limit, serverTimestamp } from 'firebase/firestore';
import { Button } from '@/components/ui/button';
import { 
  Layers, Activity, Cpu, Sparkles, X, Move, ChevronRight, 
  BellRing, Eye, EyeOff, Save, History, Video, Loader2, Zap 
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';

export default function RigelApp() {
  const [currentPose, setCurrentPose] = useState<Keyframe>(JSON.parse(JSON.stringify(TEMPLATES["T-Pose"])));
  const [timeline, setTimeline] = useState<Keyframe[]>([]);
  const [activeFrameIdx, setActiveFrameIdx] = useState<number>(-1);
  const [snapMode, setSnapMode] = useState(true);
  const [activePoint, setActivePoint] = useState<PointName | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [fps, setFps] = useState(12);
  const [isInterpolating, setIsInterpolating] = useState(false);
  const [isGeneratingVideo, setIsGeneratingVideo] = useState(false);
  const [dimensions, setDimensions] = useState<CanvasDimensions>({ width: DEFAULT_CANVAS_W, height: DEFAULT_CANVAS_H });
  const [playbackMode, setPlaybackMode] = useState<'loop' | 'once' | 'ping-pong'>('loop');
  const [isFloating, setIsFloating] = useState(false);
  const [isSidebarMinimized, setIsSidebarMinimized] = useState(false);
  const [isAvatarVisible, setIsAvatarVisible] = useState(true);
  const [isReacting, setIsReacting] = useState(false);
  const [referenceImage, setReferenceImage] = useState<string | null>(null);
  const [viewType, setViewType] = useState<ViewType>('front');
  const [generatedVideo, setGeneratedVideo] = useState<string | null>(null);
  const [isGlideMode, setIsGlideMode] = useState(false);
  const [detailLevel, setDetailLevel] = useState<'simple' | 'full'>('simple');
  
  const playTimerRef = useRef<NodeJS.Timeout | null>(null);
  const [playIdx, setPlayIdx] = useState(0);
  const directionRef = useRef(1);

  const db = useFirestore();
  
  const notificationsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'notifications'), orderBy('timestamp', 'desc'), limit(1));
  }, [db]);
  const { data: latestNotification } = useCollection(notificationsQuery);

  const recentsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'sequences'), orderBy('createdAt', 'desc'), limit(5));
  }, [db]);
  const { data: recentSequences } = useCollection(recentsQuery);

  useEffect(() => {
    if (latestNotification && latestNotification.length > 0) {
      setIsReacting(true);
      const timer = setTimeout(() => setIsReacting(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [latestNotification]);

  useEffect(() => {
    if (isPlaying && timeline.length > 0) {
      playTimerRef.current = setInterval(() => {
        setPlayIdx((prev) => {
          if (playbackMode === 'ping-pong') {
             let next = prev + directionRef.current;
             if (next >= timeline.length) {
               directionRef.current = -1;
               return Math.max(0, timeline.length - 2);
             }
             if (next < 0) {
               directionRef.current = 1;
               return Math.min(timeline.length - 1, 1);
             }
             return next;
          } else if (playbackMode === 'loop') {
             return (prev + 1) % timeline.length;
          } else {
             const next = prev + 1;
             if (next >= timeline.length) {
                setIsPlaying(false);
                return prev;
             }
             return next;
          }
        });
      }, 1000 / fps);
    } else {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    }
    return () => {
      if (playTimerRef.current) clearInterval(playTimerRef.current);
    };
  }, [isPlaying, timeline.length, fps, playbackMode]);

  const addFrame = () => {
    setTimeline(prev => [...prev, JSON.parse(JSON.stringify(currentPose))]);
    setActiveFrameIdx(-1);
  };

  const deleteFrame = (idx: number) => {
    setTimeline(prev => prev.filter((_, i) => i !== idx));
    if (activeFrameIdx === idx) setActiveFrameIdx(-1);
  };

  const selectFrame = (idx: number) => {
    setActiveFrameIdx(idx);
    setCurrentPose(JSON.parse(JSON.stringify(timeline[idx])));
    setIsPlaying(false);
  };

  const handleInterpolate = async (idx: number) => {
    if (idx >= timeline.length - 1) return;
    setIsInterpolating(true);
    try {
      const result = await interpolateKeyframes({
        startKeyframe: timeline[idx],
        endKeyframe: timeline[idx + 1],
        numFrames: 6
      });
      
      setTimeline(prev => {
        const next = [...prev];
        next.splice(idx + 1, 0, ...result.interpolatedFrames);
        return next;
      });
    } catch (error) {
      console.error("Interpolation failed", error);
    } finally {
      setIsInterpolating(false);
    }
  };

  const handleSaveSequence = () => {
    if (timeline.length === 0 || !db) return;
    const name = `Sequence ${new Date().toLocaleTimeString()}`;
    addDoc(collection(db, 'sequences'), {
      name,
      frames: timeline,
      createdAt: serverTimestamp()
    }).catch(async (err) => {
      const permissionError = new FirestorePermissionError({
        path: '/sequences',
        operation: 'create',
        requestResourceData: { name, framesCount: timeline.length }
      });
      errorEmitter.emit('permission-error', permissionError);
    });
  };

  const handleGenerateVideo = async () => {
    if (timeline.length < 2) return;
    setIsGeneratingVideo(true);
    setGeneratedVideo(null);
    try {
      const result = await generateVideo({
        description: "A professional character animation performing complex movements with facial expressions.",
        aspectRatio: dimensions.width > dimensions.height ? '16:9' : '9:16'
      });
      setGeneratedVideo(result.videoUrl);
    } catch (error) {
      console.error("Video generation failed", error);
    } finally {
      setIsGeneratingVideo(false);
    }
  };

  return (
    <div className="flex h-screen w-full bg-background overflow-hidden text-foreground">
      {/* HEADER */}
      <header className="absolute top-0 left-0 right-0 h-16 border-b border-white/5 bg-background/80 backdrop-blur-md flex items-center justify-between px-6 z-20">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-primary rounded-xl flex items-center justify-center shadow-lg shadow-primary/20">
            <Zap className="text-white w-6 h-6 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg font-bold tracking-tighter flex items-center gap-2">
              VICIOUS RIGEL <span className="text-[10px] font-medium px-2 py-0.5 bg-accent/20 text-accent border border-accent/20 rounded-full tracking-normal">ADAPT ENGINE v2</span>
            </h1>
            <p className="text-[9px] text-muted-foreground uppercase tracking-widest font-bold">Vector Character Synthesis</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
           {isReacting && (
             <div className="flex items-center gap-2 px-3 py-1 bg-accent/10 border border-accent/20 rounded-full animate-bounce">
                <BellRing className="w-3 h-3 text-accent" />
                <span className="text-[10px] font-bold text-accent uppercase">Reaction active</span>
             </div>
           )}
           <Button variant="outline" size="sm" className="gap-2 border-primary/20" onClick={handleSaveSequence}>
             <Save className="w-3 h-3" />
             Save Recents
           </Button>
        </div>
      </header>

      {/* SIDEBAR */}
      <aside className={cn(
        "h-full border-r border-white/5 pt-20 flex flex-col z-10 bg-card/50 transition-all duration-500 relative",
        isSidebarMinimized ? "w-12" : "w-80"
      )}>
        <Button 
          variant="ghost" 
          size="icon" 
          className="absolute -right-3 top-24 z-30 w-6 h-6 bg-card border border-white/10 rounded-full hover:bg-muted"
          onClick={() => setIsSidebarMinimized(!isSidebarMinimized)}
        >
          {isSidebarMinimized ? <ChevronRight className="w-3 h-3" /> : <ChevronRight className="w-3 h-3 rotate-180" />}
        </Button>

        {!isSidebarMinimized && (
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-6">
            <Controls 
              points={currentPose} 
              onPointsChange={setCurrentPose}
              snapMode={snapMode}
              onSnapToggle={() => setSnapMode(!snapMode)}
              onCapture={addFrame}
              isPlaying={isPlaying}
              onPlayToggle={() => setIsPlaying(!isPlaying)}
              onClearTimeline={() => { setTimeline([]); setIsPlaying(false); }}
              fps={fps}
              onFpsChange={setFps}
              onExport={() => {}}
              dimensions={dimensions}
              onDimensionsChange={setDimensions}
              playbackMode={playbackMode}
              onPlaybackModeChange={setPlaybackMode}
              isFloating={isFloating}
              onFloatingToggle={() => setIsFloating(!isFloating)}
              referenceImage={referenceImage}
              onReferenceImageChange={setReferenceImage}
              isAvatarVisible={isAvatarVisible}
              onAvatarVisibilityToggle={() => setIsAvatarVisible(!isAvatarVisible)}
              viewType={viewType}
              onViewTypeChange={setViewType}
              isGlideMode={isGlideMode}
              onGlideModeToggle={() => setIsGlideMode(!isGlideMode)}
              detailLevel={detailLevel}
              onDetailLevelToggle={() => setDetailLevel(prev => prev === 'simple' ? 'full' : 'simple')}
            />

            {/* RECENT SEQUENCES */}
            <div className="space-y-3 px-1 pt-4 border-t border-white/5">
              <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                <History className="w-3 h-3" /> Recents
              </h4>
              <div className="space-y-2">
                {recentSequences?.map((seq: any) => (
                  <Button 
                    key={seq.id} 
                    variant="ghost" 
                    className="w-full justify-start text-xs h-8 bg-muted/20 hover:bg-muted/40"
                    onClick={() => { setTimeline(seq.frames); setCurrentPose(seq.frames[0]); }}
                  >
                    {seq.name}
                  </Button>
                ))}
              </div>
            </div>

            {/* VIDEO GENERATION */}
            <div className="space-y-3 px-1 pt-4 border-t border-white/5">
               <h4 className="text-[10px] font-bold tracking-widest text-muted-foreground uppercase flex items-center gap-2">
                 <Video className="w-3 h-3" /> Sprite Video
               </h4>
               <Button 
                 variant="secondary" 
                 className="w-full gap-2 text-xs" 
                 disabled={timeline.length < 2 || isGeneratingVideo}
                 onClick={handleGenerateVideo}
               >
                 {isGeneratingVideo ? <Loader2 className="w-3 h-3 animate-spin" /> : <Video className="w-3 h-3" />}
                 Generate Clip
               </Button>
               {generatedVideo && (
                 <div className="mt-2 rounded-lg overflow-hidden border border-white/10 bg-black aspect-video">
                   <video src={generatedVideo} controls className="w-full h-full" />
                 </div>
               )}
            </div>
          </div>
        )}
      </aside>

      {/* MAIN CANVAS AREA */}
      <main className="flex-1 h-full relative flex flex-col pt-16">
        <div className="flex-1 flex items-center justify-center bg-[#0C0E14] relative overflow-hidden">
          <div className={cn(
            "transition-all duration-500",
            !isAvatarVisible && !isFloating && "opacity-0 scale-90 pointer-events-none",
            isFloating ? "fixed bottom-24 right-8 z-50 scale-75 shadow-3xl ring-2 ring-primary/40 rounded-2xl bg-card p-2" : "relative"
          )}>
            <RigCanvas 
              dimensions={dimensions}
              points={isPlaying && timeline.length > 0 ? timeline[playIdx] : currentPose} 
              onPointsChange={(pts) => {
                setCurrentPose(pts);
                if (activeFrameIdx !== -1) {
                  setTimeline(prev => {
                    const next = [...prev];
                    next[activeFrameIdx] = JSON.parse(JSON.stringify(pts));
                    return next;
                  });
                }
              }}
              snapMode={snapMode}
              activePoint={activePoint}
              setActivePoint={setActivePoint}
              isReacting={isReacting}
              referenceImage={referenceImage}
              viewType={viewType}
              isGlideMode={isGlideMode}
              detailLevel={detailLevel}
            />
          </div>

          {!isAvatarVisible && !isFloating && (
            <Button variant="outline" className="z-10 gap-2" onClick={() => setIsAvatarVisible(true)}>
              <Eye className="w-4 h-4" /> Restore Rig
            </Button>
          )}
        </div>

        {/* TIMELINE SECTION */}
        <div className="h-64 border-t border-white/5 bg-card/30 backdrop-blur-xl p-4 overflow-hidden">
          <Timeline 
            frames={timeline} 
            currentIndex={isPlaying ? playIdx : activeFrameIdx}
            onSelectFrame={selectFrame}
            onDeleteFrame={deleteFrame}
            onDuplicateFrame={(idx) => {
              const frame = JSON.parse(JSON.stringify(timeline[idx]));
              setTimeline(prev => {
                const next = [...prev];
                next.splice(idx + 1, 0, frame);
                return next;
              });
            }}
            onInterpolate={handleInterpolate}
            isInterpolating={isInterpolating}
          />
        </div>
      </main>
    </div>
  );
}
